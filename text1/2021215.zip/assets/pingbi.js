document.onkeydown = function (e) {
    e.stopPropagation();    // 阻止事件冒泡传递
    e.preventDefault();    // 阻止浏览器默认事件的发生
    // your code
    if (e.keyCode == 8) {        // keyCode == 8 表示按下的回退按钮
        
    }
}